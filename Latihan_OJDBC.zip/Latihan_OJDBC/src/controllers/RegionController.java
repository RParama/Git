/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import daos.RegionDAO;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import models.Region;
import tools.Connections;

/**
 *
 * @author kresna92
 */
public class RegionController {

    private RegionDAO rdao;
    private Connection connection;

    public RegionController(Connection connection) {
        rdao = new RegionDAO(connection);
    }
    
    public List<Region> getDataById(String id) {
        List<Region> regions = new ArrayList<Region>();
        try {
            int idINT = new Integer (id);
                regions = rdao.getData(idINT, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return regions;
    }

    public boolean insert(String id, String name) {
        boolean result = false;
        try {
            rdao.save(Region(id, name), true));
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    
    public boolean update(String id, String name) {
        boolean result = false;
        try {
            rdao.save(new Region(id, name), false);
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    
    public boolean delete(String id){
        boolean result = false;
        try {
            rdao.delete(new Region(id));
            result = true;
        } catch (Exception e) {
        }
        return result;
    }
    
}
